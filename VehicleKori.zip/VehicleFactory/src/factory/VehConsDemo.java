package factory;

public class VehConsDemo {
	public static void main(String[] args) {

		//construct complete vehicle
		// passengers, fuelcap, mpg, doors, tonage, year, totalmiles, wheelsize
		Vehicle minivan = new Vehicle(7, 16, 21, 5, 2, 2005, 250, 16);
		Vehicle sportscar = new Vehicle(2, 14, 12, 2, 1, 2019, 50, 20);
		double gallons;
		String color, color2;
		int dist = 252;
		int refill, refill2;
		int x = 500;

		gallons = minivan.fuelneeded(dist);
		color = minivan.color("blue");
		refill = (int) minivan.gasrefill(x);

		System.out.println("To go " + dist + " miles minivan needs " + gallons + " gallons of fuel. The color of "
				+ "the vehicle is " + color + ". The amount of refills to drive 500 miles is " + refill);

		gallons = sportscar.fuelneeded(dist);
		color2 = sportscar.color("red");
		refill2 = (int) sportscar.gasrefill(x);

		System.out.println("To go " + dist + " miles sportscar needs " + gallons + " gallons of fuel. The color of "
				+ "the vehicle is " + color2 + ". The amount of refills to drive 500 miles is " + refill2);
	}
}
