package factory;

public class Vehicle {
	int passengers;
	int fuelcap;
	int mpg; 
	int doors;
	int tonage; 
	int year;
	int totalmiles;
	int wheelsize; 

	Vehicle(){}

	Vehicle(int p, int f, int m, int d, int t, int y, int tm, int ts){
		passengers = p;
		fuelcap = f;
		mpg = m;
		doors = d;
		tonage = t;
		year = y;
		totalmiles = tm;
		wheelsize = ts;
	}
	
	//gasrefill
	double gasrefill (int dist) {
		return (int) dist / range() + 1;
	}
	
	//return the color
	String color (String x) {
		return x;
	}

	//return the range
	int range() {
		return mpg * fuelcap;
	}

	//compute fuel to travel a specific distance
	double fuelneeded(int miles) {
		return (double) miles/mpg;
	}
}
